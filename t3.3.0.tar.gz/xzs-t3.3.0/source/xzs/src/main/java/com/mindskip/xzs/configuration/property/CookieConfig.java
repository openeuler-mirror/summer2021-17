package com.mindskip.xzs.configuration.property;

public class CookieConfig {

    public static String getName() {
        return "xzs";
    }

    public static Integer getInterval() {
        return 30 * 24 * 60 * 60;
    }
}
